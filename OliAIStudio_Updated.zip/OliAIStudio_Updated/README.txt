OLI AI STUDIO — UPDATED VERSION

1. Extract this folder into Documents and name the folder OliAIStudio.
2. Open Command Prompt and run:

   cd /d "%USERPROFILE%\Documents\OliAIStudio"
   py -m pip install streamlit edge-tts imageio-ffmpeg pillow requests
   py -m streamlit run app1.py

3. Edit narration (one scene per line), select a voice, then click Generate MP4 video.
4. Videos are saved in the OliVideos folder.
5. The app downloads fruit photos into images. If a photo download fails, a simple
   fallback drawing is used for that scene.

Keep ATTRIBUTION.txt and check image licenses before publishing.
